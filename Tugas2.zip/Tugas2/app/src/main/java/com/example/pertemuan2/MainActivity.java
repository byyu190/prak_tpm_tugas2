package com.example.pertemuan2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSubmit    = findViewById(R.id.btn_submit);
        EditText etNama     = findViewById(R.id.etnama);
        EditText etNIM      = findViewById(R.id.etnim);
        EditText etNilai    = findViewById(R.id.etnilai);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    /**
                     * Passing data via Intent
                     */

                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    intent.putExtra("nama", etNama.getText().toString());
                    intent.putExtra("nim", etNIM.getText().toString());

                    String snilai   = etNilai.getText().toString();
                    double nilai   = Double.parseDouble(snilai);

                    if(nilai <= 4.00){
                        if(nilai > 3.66 && nilai <= 4.00){
                            intent.putExtra("nilai", "A");
                        }else if(nilai > 3.33 && nilai <= 3.66) {
                            intent.putExtra("nilai", "A-");
                        }else if(nilai > 3.00 && nilai <= 3.33) {
                            intent.putExtra("nilai", "B+");
                        }else if(nilai > 2.66 && nilai <= 3.00) {
                            intent.putExtra("nilai", "B");
                        }else if(nilai > 2.33 && nilai <= 2.66) {
                            intent.putExtra("nilai", "B-");
                        }else if(nilai > 2.00 && nilai <= 2.33) {
                            intent.putExtra("nilai", "C+");
                        }else if(nilai > 1.66 && nilai <= 2.00) {
                            intent.putExtra("nilai", "C");
                        }else if(nilai > 1.33 && nilai <= 1.66) {
                            intent.putExtra("nilai", "C-");
                        }else if(nilai > 1.00 && nilai <= 1.33) {
                            intent.putExtra("nilai", "D+");
                        }else {
                            intent.putExtra("nilai", "D");
                        }
                        startActivity(intent);
                    }else {
                        Toast.makeText(getApplication(), "Harus dibawah 4.00", Toast.LENGTH_SHORT).show();
                    }

                    startActivity(intent);
                }catch(NumberFormatException nfe){ Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong",Toast.LENGTH_SHORT).show();}


            }
        });
    }
}