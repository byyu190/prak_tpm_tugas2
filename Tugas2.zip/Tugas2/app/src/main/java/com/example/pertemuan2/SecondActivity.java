package com.example.pertemuan2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hasil);

        TextView tvNama     = findViewById(R.id.tvnama);
        TextView tvNim      = findViewById(R.id.tvnim);
        TextView tvNilai = findViewById(R.id.tvnilai);

        tvNama.setText(getIntent().getStringExtra("nama"));
        tvNim.setText(getIntent().getStringExtra("nim"));
        tvNilai.setText(getIntent().getStringExtra("nilai"));
    }
}
